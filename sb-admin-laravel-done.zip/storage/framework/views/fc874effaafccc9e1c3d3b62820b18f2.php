<header class="page-header page-header-dark bg-primary pb-10">
    <div class="container-xl px-4">
        <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
                <div class="col-auto mt-4">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i data-feather="<?php echo $__env->yieldContent('dashboard_icon'); ?>"></i></div>
                        <?php echo $__env->yieldContent('dashboard_title'); ?>
                    </h1>
                    <div class="page-header-subtitle"><?php echo $__env->yieldContent('dashboard_subtitle'); ?></div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/layouts/header.blade.php ENDPATH**/ ?>