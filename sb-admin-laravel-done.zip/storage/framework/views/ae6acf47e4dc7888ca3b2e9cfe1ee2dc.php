  <!-- Side Nav -->
  <div id="layoutSidenav_nav">
      <nav class="sidenav shadow-right sidenav-light">
          <div class="sidenav-menu">
              <div class="nav accordion" id="accordionSidenav">
                  <!-- Sidenav Menu Heading (Account)-->
                  <div class="sidenav-menu-heading d-sm-none">Account</div>
                  <!-- Sidenav Link (Alerts)-->
                  <a class="nav-link d-sm-none" href="#!">
                      <div class="nav-link-icon"><i data-feather="bell"></i></div>
                      Alerts
                      <span class="badge bg-warning-soft text-warning ms-auto">4 New!</span>
                  </a>
                  <!-- Sidenav Link (Messages)-->
                  <a class="nav-link d-sm-none" href="#!">
                      <div class="nav-link-icon"><i data-feather="mail"></i></div>
                      Messages
                      <span class="badge bg-success-soft text-success ms-auto">2 New!</span>
                  </a>
                  <!-- Sidenav Menu Heading (Dashboard)-->
                  <div class="sidenav-menu-heading">Dashboard</div>

                  <!-- Sidenav Link (Dashboard)-->
                  <a class="nav-link <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>" href="<?php echo e(url('/dashboard')); ?>">
                      <div class="nav-link-icon"><i data-feather="activity"></i></div>
                      Dashboard
                  </a>

                  <!-- Sidenav Heading (Master Data)-->
                  <div class="sidenav-menu-heading">Master Data</div>

                  <!-- Sidenav Link (Event)-->
                  <a class="nav-link <?php echo e(request()->is('event') ? 'active' : ''); ?>" href="charts.html">
                      <div class="nav-link-icon"><i data-feather="briefcase"></i></div>
                      Event

                  </a><!-- Sidenav Link (Inventory)-->
                  <a class="nav-link <?php echo e(request()->is('inventory') ? 'active' : ''); ?>" href="charts.html">
                      <div class="nav-link-icon"><i data-feather="box"></i></div>
                      Inventory

                  </a><!-- Sidenav Link (Karyawan)-->
                  <a class="nav-link <?php echo e(request()->is('karyawan') ? 'active' : ''); ?>" href="<?php echo e(url('/karyawan')); ?>">
                      <div class="nav-link-icon"><i data-feather="user"></i></div>
                      Karyawan
                  </a>

              </div>
          </div>
          <!-- Sidenav Footer-->
          <div class="sidenav-footer">
              <div class="sidenav-footer-content">
                  <div class="sidenav-footer-subtitle">Logged in as:</div>
                  <div class="sidenav-footer-title"><?php if(auth()->guard()->check()): ?><?php echo e(Auth::user()->name); ?><?php endif; ?>
                  </div>
              </div>
          </div>
      </nav>
  </div>
<?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/layouts/sidenav.blade.php ENDPATH**/ ?>