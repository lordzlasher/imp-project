

<?php
    $useHeader = true;
    $useCompactHeader = false;
?>

<?php $__env->startSection('header-icon', 'box'); ?>
<?php $__env->startSection('header-title', 'Master Inventory'); ?>
<?php $__env->startSection('header-subtitle', 'Data Inventory Gudang Indonesia Multimedia Project Cab. Bali'); ?>


<?php $__env->startSection('content'); ?>
    <!-- Main page content-->
    <div class="container-xl px-4 mt-n10">
        <!-- Include Alert Component -->
        <?php if(session('success')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'success'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('success')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php elseif(session('warning')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'warning'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('warning')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php elseif(session('danger')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'danger'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('danger')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php else: ?>
        <?php endif; ?>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Table Inventory</span>
                <a class="btn btn-sm btn-success" href="<?php echo e(route('inventory.create')); ?>">
                    <i class="me-2" data-feather="plus"></i>
                    Add New Inventory
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Barang</th>
                                <th>Jumlah</th>
                                <th>Satuan</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($row->nama); ?></td>
                                    <td><?php echo e($row->jumlah); ?></td>
                                    <td><?php echo e($row->satuan); ?></td>
                                    <td>
                                        <a class="btn btn-sm btn-warning me-2"
                                            href="<?php echo e(url('inventory/' . $row->id . '/edit')); ?>"><i
                                                class="fas fa-edit me-2"></i>Edit</a>
                                        <a class="btn btn-sm btn-danger"
                                            href="<?php echo e(url('inventory/' . $row->id . '/delete')); ?>" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal<?php echo e($row->id); ?>"><i
                                                class="fas fa-trash me-2"></i>Hapus</a>

                                        <!-- Delete Modal -->
                                        <?php echo $__env->make('components.modal-delete-inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/inventory/index.blade.php ENDPATH**/ ?>