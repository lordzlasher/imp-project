

<?php
    $useHeader = true;
    $useCompactHeader = true;
?>
<?php $__env->startSection('header-icon', 'briefcase'); ?>
<?php $__env->startSection('header-title', 'Add Event'); ?>
<?php $__env->startSection('back-link', route('event.index')); ?>
<?php $__env->startSection('back-desc', 'Back to Event List'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <form method="post" enctype="multipart/form-data" action="<?php echo e(route('event.store')); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="row gx-4">
                <div class="col-xl-8">
                    <!-- Event details card-->
                    <div class="card mb-4">
                        <div class="card-header">Event Details</div>
                        <div class="card-body">
                            <!-- Form Row-->
                            <div class="row gx-3 mb-3">
                                <!-- Form Tanggal Loading -->
                                <div class="mb-3">
                                    <label class="small mb-1" for="inputTglLoading">Tanggal Loading</label>
                                    <input class="form-control <?php $__errorArgs = ['tanggal_loading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="litepickerSingleDate" name="tanggal_loading"
                                        placeholder="Masukan Tanggal Loading Barang..." value="<?php echo e(old('tanggal_loading')); ?>"
                                        autocomplete="off" />
                                    <?php $__errorArgs = ['tanggal_loading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger" for="inputTglLoading"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <!-- Form Tanggal Acara -->
                                <div class="mb-3">
                                    <label class="small mb-1" for="inputTanggalAcara">Tanggal Acara</label>
                                    <input class="form-control <?php $__errorArgs = ['tanggal_acara[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="tanggal_acara[]" id="litepickerDateRange"
                                        placeholder="Select Tanggal Acara..." value="<?php echo e(old('tanggal_acara[]')); ?>"
                                        autocomplete="off" />
                                    <?php $__errorArgs = ['tanggal_acara[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger"
                                            for="inputTanggalAcara"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <!-- Form Ukuran LED -->
                                <div class="mb-3">
                                    <label class="small mb-1" for="inputUkuran">Ukuran LED</label>
                                    <!-- Date Range Picker Example-->
                                    <input class="form-control <?php $__errorArgs = ['ukuran_led'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ukuran_led"
                                        id="ukuran_led" placeholder="Masukan Ukuran LED..." type="text"
                                        value="<?php echo e(old('ukuran_led')); ?>" />
                                    <?php $__errorArgs = ['ukuran_led'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger" for="inputUkuran"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <!-- Form Venue -->
                                <div class="mb-3">
                                    <label class="small mb-1" for="inputVenue">Venue</label>
                                    <!-- Date Range Picker Example-->
                                    <input class="form-control <?php $__errorArgs = ['venue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="venue"
                                        id="venue" type="text" placeholder="Masukan Venue Event..."
                                        value="<?php echo e(old('venue')); ?>" />
                                    <?php $__errorArgs = ['venue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger" for="inputVenue"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <!-- Form Client -->
                                <div class="mb-3">
                                    <label class="small mb-1" for="inputUkuran">Client</label>
                                    <!-- Date Range Picker Example-->
                                    <input class="form-control <?php $__errorArgs = ['client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="client"
                                        id="client" placeholder="Masukan Client..." type="text"
                                        value="<?php echo e(old('client')); ?>" />
                                    <?php $__errorArgs = ['client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger" for="inputUkuran"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <!-- Form Kategori Event -->
                                <div class="mb-3">
                                    <label class="small mb-1" for="inputCrew">Ketegori Event</label>
                                    <select class="form-select <?php $__errorArgs = ['kategori_event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="kategori_event" id="kategori_event">
                                        <option selected hidden>Pilih Ketegori Event...</option>
                                        <?php $__currentLoopData = $kategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->kategori_event); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['kategori_event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger" for="inputCrew"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <!-- Form Note -->
                                <div class="mb-3">
                                    <label class="small mb-1" for="inputNote">Note</label>
                                    <!-- Date Range Picker Example-->
                                    <input class="form-control <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="note"
                                        id="note" type="text" placeholder="Masukan Note untuk Event..."
                                        value="<?php echo e(old('venue')); ?>" />
                                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger" for="inputNote"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span>Crew Event</span>
                            <button class="btn btn-sm btn-success" type="button" onclick="addCrewForm()">
                                <i class="me-2" data-feather="user-plus"></i>
                                Add More Crew
                            </button>
                        </div>
                        <div class="card-body">
                            <div id="crew-form-container">
                                <!-- Form Row-->
                                <div class="row gx-3 mb-3">
                                    <!-- Form Crew -->
                                    <div class="mb-3">
                                        <label class="small mb-1" for="inputCrew">Crew</label>
                                        <select class="form-select <?php $__errorArgs = ['karyawan[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="karyawan[]" id="karyawan[]">
                                            <option selected disabled hidden>Pilih Crew...</option>
                                            <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karyawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($karyawan->id); ?>"><?php echo e($karyawan->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['karyawan[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <label class="small mb-1 text-danger" for="inputCrew"><?php echo e($message); ?></label>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <!-- Form Status Crew -->
                                    <div class="mb-3">
                                        <label class="small mb-1" for="inputStatus">Status</label>
                                        <select class="form-select <?php $__errorArgs = ['status_crew'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="status_crew" id="status_crew">
                                            <option selected disabled hidden>Pilih Status Crew...</option>
                                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($status->id); ?>"><?php echo e($status->status_crew); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['status_crew'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <label class="small mb-1 text-danger"
                                                for="inputStatus"><?php echo e($message); ?></label>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <!-- Form Keterangan -->
                                    <div class="mb-3">
                                        <label class="small mb-1" for="inputKeterangan">Keterangan</label>
                                        <select class="form-select <?php $__errorArgs = ['keterangan_crew'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="keterangan_crew" id="keterangan_crew">
                                            <option selected disabled hidden>Pilih Status Crew...</option>
                                            <?php $__currentLoopData = $keterangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keterangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($keterangan->id); ?>"><?php echo e($keterangan->keterangan_crew); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['keterangan_crew'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <label class="small mb-1 text-danger"
                                                for="inputStatus"><?php echo e($message); ?></label>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card card-header-actions">
                        <div class="card-header">
                            Simpan
                        </div>
                        <div class="card-body">
                            <div class="d-grid"><button class="fw-500 btn btn-primary">Simpan</button></div>
                        </div>
                    </div>
                </div>

            </div>
        </form>
    </div>

    <script>
        let crewFormIndex = 0;

        function addCrewForm() {
            crewFormIndex++;

            const crewFormContainer = document.getElementById('crew-form-container');
            const newCrewForm = document.createElement('div');
            newCrewForm.innerHTML = `
            <div class="card-header d-flex justify-content-between align-items-center">Crew Event ${crewFormIndex}</div>
            <div class="row gx-3 mb-3"> 
                <!-- Form Crew -->
                <div class="mb-3">
                    <label class="small mb-1" for="inputCrew_${crewFormIndex}">Crew</label>
                    <select class="form-select <?php $__errorArgs = ['karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="karyawan[]" id="karyawan_${crewFormIndex}">
                        <option selected disabled>Pilih Crew...</option>
                        <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karyawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($karyawan->id); ?>"><?php echo e($karyawan->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <label class="small mb-1 text-danger" for="inputCrew_${crewFormIndex}"><?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Form Status Crew -->
                    <div class="mb-3">
                        <label class="small mb-1" for="inputStatus_${crewFormIndex}">Status</label>
                        <select class="form-select <?php $__errorArgs = ['status_crew'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status_crew" id="status_crew_${crewFormIndex}">
                            <option selected disabled hidden>Pilih Status Crew...</option>
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status->id); ?>"><?php echo e($status->status_crew); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['status_crew'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="small mb-1 text-danger" for="inputStatus_${crewFormIndex}"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <!-- Form Keterangan -->
                <div class="mb-3">
                    <label class="small mb-1" for="inputKeterangan_${crewFormIndex}">Keterangan</label>
                    <select class="form-select <?php $__errorArgs = ['keterangan_crew'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="keterangan_crew" id="keterangan_crew_${crewFormIndex}">
                        <option selected disabled hidden>Pilih Status Crew...</option>
                            <?php $__currentLoopData = $keterangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keterangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($keterangan->id); ?>"><?php echo e($keterangan->keterangan_crew); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['keterangan_crew'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <label class="small mb-1 text-danger" for="inputKeterangan_${crewFormIndex}"><?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        `;

            crewFormContainer.appendChild(newCrewForm);
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/event/create.blade.php ENDPATH**/ ?>