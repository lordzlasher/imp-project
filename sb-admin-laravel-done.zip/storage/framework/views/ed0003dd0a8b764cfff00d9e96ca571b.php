

<?php
    $useHeader = true;
    $useCompactHeader = false;
?>

<?php $__env->startSection('header-icon', 'briefcase'); ?>
<?php $__env->startSection('header-title', 'Master Event'); ?>
<?php $__env->startSection('header-subtitle', 'Data Event Indonesia Multimedia Project Cab. Bali'); ?>


<?php $__env->startSection('content'); ?>
    <!-- Main page content-->
    <div class="container-xl px-4 mt-n10">
        <!-- Custom page header alternative example-->
        <div class="d-flex justify-content-end align-items-sm-center flex-column flex-sm-row mb-4">
            <!-- Date range picker example-->
            <form method="post" class='d-flex justify-content-end align-items-sm-center flex-column flex-sm-row mb-4'
                enctype="multipart/form-data" action="<?php echo e(route('filter')); ?>">
                <?php echo csrf_field(); ?>
                <div class="input-group input-group-joined border-0 shadow" style="width: 16.5rem">
                    <span class="input-group-text"><i data-feather="calendar"></i></span>
                    <input class="form-control ps-0 pointer" id="litepickerRangeDashboard" name="filter_date"
                        placeholder="Select date range..." />
                </div>
                <div class="ms-2">
                    <button class="btn btn-primary" type="submit">Filter</button>
                </div>
            </form>
        </div>
        <!-- Include Alert Component -->
        <?php if(session('success')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'success'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('success')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php elseif(session('warning')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'warning'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('warning')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php elseif(session('danger')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'danger'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('danger')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php else: ?>
        <?php endif; ?>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Table Event Bali</span>
                <div class="d-flex">
                    <a class="btn btn-sm btn-success me-2" href="<?php echo e(route('event.create')); ?>">
                        <i class="me-2" data-feather="plus"></i>
                        Add New Event
                    </a>
                    <?php if(isset($eventBali[0])): ?>
                        <a class="btn btn-sm btn-primary me-2"
                            href="<?php echo e(route('report.eventKategori', $eventBali[0]->id_kategori_event)); ?>" target="_blank">
                            <i class="me-2" data-feather="download"></i>
                            Report Excel
                        </a>
                        <a class="btn btn-sm btn-primary"
                            href="<?php echo e(route('report.eventKategori', $eventBali[0]->id_kategori_event)); ?>" target="_blank">
                            <i class="me-2" data-feather="download"></i>
                            Report PDF
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTableBali" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal Loading</th>
                                <th>Tanggal Acara</th>
                                <th>Ukuran</th>
                                <th>Venue</th>
                                <th>Client</th>
                                <th>Kategori</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $eventBali; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($event->getTanggalLoadingFormattedAttribute()); ?></td>
                                    <td><?php echo e($event->getFormattedDateRangeAttribute()); ?></td>
                                    <td><?php echo e($event->ukuran_led); ?></td>
                                    <td><?php echo e($event->venue); ?></td>
                                    <td><?php echo e($event->client); ?></td>
                                    <td><?php echo e($event->kategoriEvent->kategori_event); ?></td>
                                    <td>
                                        <a class="btn btn-sm btn-info me-2" href="<?php echo e(url('event/' . $event->id)); ?>"><i
                                                class="fas fa-eye me-2"></i>Detail</a>
                                        <a class="btn btn-sm btn-danger"
                                            href="<?php echo e(url('event/' . $event->id . '/delete')); ?>" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal<?php echo e($event->id); ?>"><i
                                                class="fas fa-trash me-2"></i>Hapus</a>

                                        <!-- Delete Modal -->
                                        <?php echo $__env->make('components.modal-event.modal-delete-event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Table Event Surabaya</span>
                <div class="d-flex">
                    <?php if(isset($eventBali[0])): ?>
                        <a class="btn btn-sm btn-primary"
                            href="<?php echo e(route('report.eventKategori', $eventSurabaya[0]->id_kategori_event)); ?>" target="_blank">
                            <i class="me-2" data-feather="download"></i>
                            Report PDF
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTableSurabaya" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal Loading</th>
                                <th>Tanggal Acara</th>
                                <th>Ukuran</th>
                                <th>Venue</th>
                                <th>Client</th>
                                <th>Kategori</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $eventSurabaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($event->getTanggalLoadingFormattedAttribute()); ?></td>
                                    <td><?php echo e($event->getFormattedDateRangeAttribute()); ?></td>
                                    <td><?php echo e($event->ukuran_led); ?></td>
                                    <td><?php echo e($event->venue); ?></td>
                                    <td><?php echo e($event->client); ?></td>
                                    <td><?php echo e($event->kategoriEvent->kategori_event); ?></td>
                                    <td>
                                        <a class="btn btn-sm btn-info me-2" href="<?php echo e(url('event/' . $event->id)); ?>"><i
                                                class="fas fa-eye me-2"></i>Detail</a>
                                        <a class="btn btn-sm btn-danger"
                                            href="<?php echo e(url('event/' . $event->id . '/delete')); ?>" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal<?php echo e($event->id); ?>"><i
                                                class="fas fa-trash me-2"></i>Hapus</a>

                                        <!-- Delete Modal -->
                                        <?php echo $__env->make('components.modal-event.modal-delete-event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <hr class="mt-0 mb-4" />

        <div class="event justify-content-end">
            <div class="col-lg-3 mb-4">
                <!-- Total Event-->
                <div class="card h-80 border-start-lg border-start-primary">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-gevent-1">
                                <div class="text mb-2">Total Event</div>
                                <div class="h1"><?php echo e(count($events)); ?> <span class="fw-500 text-primary">events</span>
                                </div>
                            </div>
                            <div class="ms-2"><i class="fas fa-briefcase fa-2x text-gray-200"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
    <script>
        window.addEventListener('DOMContentLoaded', event => {
            const litepickerRangeDashboard = document.getElementById('litepickerRangeDashboard');
            if (litepickerRangeDashboard) {
                const startDateSession = '<?php echo e(session('start_date')); ?>';
                const endDateSession = '<?php echo e(session('end_date')); ?>';

                const startDate = startDateSession ? new Date(startDateSession) : new Date();
                const endDate = endDateSession ? new Date(endDateSession) : new Date();

                new Litepicker({
                    element: litepickerRangeDashboard,
                    startDate: startDate,
                    endDate: endDate,
                    singleMode: false,
                    numberOfMonths: 2,
                    numberOfColumns: 2,
                    format: 'MMM DD, YYYY',
                    plugins: ['ranges'],
                    dropdowns: {
                        months: true,
                        years: true
                    },
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/event/index.blade.php ENDPATH**/ ?>