

<?php
    $useHeader = true;
    $useCompactHeader = true;
?>
<?php $__env->startSection('header-icon', 'archive'); ?>
<?php $__env->startSection('header-title', 'Add Inventory Log'); ?>
<?php $__env->startSection('back-link', route('inventory-log.index')); ?>
<?php $__env->startSection('back-desc', 'Back to Inventory Log List'); ?>



<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <!-- Include Alert Component -->
        <?php if(session('danger')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'danger'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('danger')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
        <form method="post" enctype="multipart/form-data" action="<?php echo e(route('inventory-log.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row gx-4">
                <div class="col-xl-8">
                    <!-- Account details card-->
                    <div class="card mb-4">
                        <div class="card-header">Log Inventory</div>
                        <div class="card-body">
                            <!-- Form Row-->
                            <div class="row gx-3 mb-3">
                                <!-- Form Nama barang-->
                                <div class="mb-3">
                                    <label class="small mb-1">Nama Barang</label>
                                    <select class="form-select <?php $__errorArgs = ['barang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="barang"
                                        name="barang_id">
                                        <option selected disabled hidden>Pilih Barang...</option>
                                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($barang->id); ?>"><?php echo e($barang->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['barang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger" for="inputSatuan"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Form jumlah -->
                                <div class="mb-3">
                                    <label class="small mb-1" for="inputJumlah">Jumlah Barang</label>
                                    <input class="form-control <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah"
                                        name="jumlah" type="number" placeholder="Masukan jumlah barang..."
                                        value="<?php echo e(old('jumlah')); ?>" />
                                    <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger" for="inputJumlah"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <!-- Form Status-->
                                <div class="mb-3">
                                    <label class="small mb-1">Status Barang</label>
                                    <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status"
                                        name="status">
                                        <option selected disabled hidden>Pilih Status...</option>
                                        <option value="Barang Masuk">Barang Masuk</option>
                                        <option value="Barang Keluar">Barang Keluar</option>

                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger" for="inputSatuan"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card card-header-actions">
                        <div class="card-header">
                            Simpan
                        </div>
                        <div class="card-body">
                            <div class="d-grid"><button class="fw-500 btn btn-primary">Simpan</button></div>
                        </div>
                    </div>
                </div>

            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/inventory-log/create.blade.php ENDPATH**/ ?>