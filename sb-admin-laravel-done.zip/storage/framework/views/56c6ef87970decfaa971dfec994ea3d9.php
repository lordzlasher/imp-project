<div class="alert alert-<?php echo e($alertType); ?> alert-dismissible fade show" role="alert">
    <?php echo e($alertMessage); ?>

    <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/components/alert.blade.php ENDPATH**/ ?>