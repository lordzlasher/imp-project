 
 <div class="modal fade" id="editEventModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
     
     <div class="modal-dialog modal-xl" role="document">
         <div class="modal-content">
             <form enctype="multipart/form-data" action="<?php echo e(route('event.updateEvent', $events)); ?>" method="POST">
                 <?php echo csrf_field(); ?>
                 <?php echo method_field('PUT'); ?>
                 <div class="modal-header">
                     <h5 class="modal-title" id="exampleModalCenterTitle">Edit Event
                     </h5>
                     <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                 </div>
                 <div class="modal-body">
                     <div class="card-body">
                         <div id="crew-form-container">
                             <!-- Form Row-->
                             <div class="row gx-3 mb-3">
                                 <!-- Form Tanggal Loading -->
                                 <div class="mb-3">
                                     <label class="small mb-1" for="inputTglLoading">Tanggal Loading</label>
                                     <input class="form-control <?php $__errorArgs = ['tanggal_loading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                         id="litepickerSingleDate" name="tanggal_loading"
                                         placeholder="Masukan Tanggal Loading Barang..."
                                         value="<?php echo e($events->tanggal_loading); ?>" autocomplete="off" />
                                     <?php $__errorArgs = ['tanggal_loading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         <label class="small mb-1 text-danger"
                                             for="inputTglLoading"><?php echo e($message); ?></label>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <!-- Form Tanggal Acara -->
                                 <div class="mb-3">
                                     <label class="small mb-1" for="inputTanggalAcara">Tanggal Acara</label>
                                     <input class="form-control <?php $__errorArgs = ['tanggal_acara[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                         name="tanggal_acara[]" id="litepickerDateRange"
                                         placeholder="Select Tanggal Acara..." value="<?php echo e($input_tanggal_acara); ?>"
                                         autocomplete="off" />
                                     <?php $__errorArgs = ['tanggal_acara[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         <label class="small mb-1 text-danger"
                                             for="inputTanggalAcara"><?php echo e($message); ?></label>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <!-- Form Ukuran LED -->
                                 <div class="mb-3">
                                     <label class="small mb-1" for="inputUkuran">Ukuran LED</label>
                                     <!-- Date Range Picker Example-->
                                     <input class="form-control <?php $__errorArgs = ['ukuran_led'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                         name="ukuran_led" id="ukuran_led" placeholder="Masukan Ukuran LED..."
                                         type="text" value="<?php echo e($events->ukuran_led); ?>" />
                                     <?php $__errorArgs = ['ukuran_led'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         <label class="small mb-1 text-danger" for="inputUkuran"><?php echo e($message); ?></label>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <!-- Form Venue -->
                                 <div class="mb-3">
                                     <label class="small mb-1" for="inputVenue">Venue</label>
                                     <!-- Date Range Picker Example-->
                                     <input class="form-control <?php $__errorArgs = ['venue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="venue"
                                         id="venue" type="text" placeholder="Masukan Venue Event..."
                                         value="<?php echo e($events->venue); ?>" />
                                     <?php $__errorArgs = ['venue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         <label class="small mb-1 text-danger" for="inputVenue"><?php echo e($message); ?></label>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <!-- Form Client -->
                                 <div class="mb-3">
                                     <label class="small mb-1" for="inputUkuran">Client</label>
                                     <!-- Date Range Picker Example-->
                                     <input class="form-control <?php $__errorArgs = ['client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="client"
                                         id="client" placeholder="Masukan Client..." type="text"
                                         value="<?php echo e($events->client); ?>" " />
                                     <?php $__errorArgs = ['client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <label class="small mb-1 text-danger"
                                                                         for="inputUkuran"><?php echo e($message); ?></label>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <!-- Form Kategori Event -->
                                 <div class="mb-3">
                                     <label class="small mb-1" for="inputCrew">Ketegori Event</label>
                                     <select class="form-select <?php $__errorArgs = ['kategori_event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                         name="kategori_event" id="kategori_event">
                                         <option selected hidden value="<?php echo e($events->id_kategori_event); ?>"><?php echo e($events->kategoriEvent->kategori_event); ?>

                                         </option>
                                       <?php $__currentLoopData = $kategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->kategori_event); ?>

                                     </option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                     <?php $__errorArgs = ['kategori_event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         <label class="small mb-1 text-danger" for="inputCrew"><?php echo e($message); ?></label>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <!-- Form Note -->
                                 <div class="mb-3">
                                     <label class="small mb-1" for="inputNote">Note</label>
                                     <!-- Date Range Picker Example-->
                                     <input class="form-control <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="note"
                                         id="note" type="text" placeholder="Masukan Note untuk Event..."
                                         value="<?php echo e($events->note); ?>" />
                                     <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         <label class="small mb-1 text-danger" for="inputNote"><?php echo e($message); ?></label>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="modal-footer">
                     <button class="btn btn-danger" type="button" data-bs-dismiss="modal">Close</button>
                     <button class="btn btn-primary" type="submit">Save
                         changes</button>
                 </div>
             </form>
         </div>
     </div>
 </div>
<?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/components/modal-event/modal-update-event.blade.php ENDPATH**/ ?>