

<?php
    $useHeader = true;
    $useCompactHeader = false;
?>

<?php $__env->startSection('header-icon', 'user'); ?>
<?php $__env->startSection('header-title', 'Master Karyawan'); ?>
<?php $__env->startSection('header-subtitle', 'Data Karyawan Indonesia Multimedia Project'); ?>


<?php $__env->startSection('content'); ?>
    <!-- Main page content-->
    <div class="container-fluid px-4 mt-n10">

        <!-- Include Alert Component -->
        <?php if(session('success')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'success'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('success')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php elseif(session('warning')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'warning'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('warning')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php elseif(session('danger')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'danger'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('danger')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php else: ?>
        <?php endif; ?>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Table Karyawan</span>
                <a class="btn btn-sm btn-success" href="<?php echo e(route('karyawan.create')); ?>">
                    <i class="me-2" data-feather="user-plus"></i>
                    Add New Karyawan
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Nomer Hp</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($row->nama); ?></td>
                                    <td><?php echo e($row->alamat); ?></td>
                                    <td><?php echo e($row->nomer_hp); ?></td>
                                    <td>
                                        <a class="btn btn-sm btn-info me-2" href="<?php echo e(url('karyawan/' . $row->id)); ?>"> <i
                                                class="fas fa-eye me-2"></i>Detail</a>
                                        <a class="btn btn-sm btn-warning me-2"
                                            href="<?php echo e(url('karyawan/' . $row->id . '/edit')); ?>"> <i
                                                class="fas fa-edit me-2"></i>Edit</a>
                                        <a class="btn btn-sm btn-danger"
                                            href="<?php echo e(url('karyawan/' . $row->id . '/delete')); ?>" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal<?php echo e($row->id); ?>"><i
                                                class="fas fa-trash me-2"></i>Hapus</a>

                                        <!-- Delete Modal -->
                                        <?php echo $__env->make('components.modal-delete-karyawan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/karyawan/index.blade.php ENDPATH**/ ?>