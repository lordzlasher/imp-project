


<?php
    $useHeader = true;
    $useCompactHeader = false;
?>


<?php $__env->startSection('header-icon', 'briefcase'); ?>
<?php $__env->startSection('header-title', 'Event'); ?>
<?php $__env->startSection('header-subtitle', 'Data Event Indonesia Multimedia Project Cab. Bali'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4 mt-n10">
        <!-- Include Alert Component -->
        <?php if(session('success')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'success'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('success')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php elseif(session('warning')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'warning'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('warning')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php elseif(session('danger')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'danger'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('danger')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php else: ?>
        <?php endif; ?>

        
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Table Event</span>
                <div class="d-flex">
                    <a class="btn btn-sm btn-success me-2" href="<?php echo e(route('event.updateEvent', $events)); ?>" type="button"
                        data-bs-toggle="modal" data-bs-target="#editEventModal">
                        <i class="me-2" data-feather="edit"></i>
                        Update Event
                    </a>
                    <a class="btn btn-sm btn-primary" type="button" onclick="copyContent()">
                        <i class="me-2" data-feather="copy"></i>
                        Copy Event
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTableShowEvent" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Tanggal Loading</th>
                                <th>Tanggal Acara</th>
                                <th>Ukuran</th>
                                <th>Venue</th>
                                <th>Client</th>
                                <th>Kategori</th>
                                <th>Note</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($events->tanggal_loading_formatted); ?></td>
                                <td><?php echo e($events->getFormattedDateRangeAttribute()); ?></td>
                                <td><?php echo e($events->ukuran_led); ?></td>
                                <td><?php echo e($events->venue); ?></td>
                                <td><?php echo e($events->client); ?></td>
                                <td><?php echo e($events->kategoriEvent->kategori_event); ?></td>
                                <td><?php echo e($events->note); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <?php echo $__env->make('components.modal-event.modal-update-event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Table Karyawan</span>
                <a class="btn btn-sm btn-success" href="<?php echo e(route('event.storeCrew', ['eventId' => $events->id])); ?>"
                    type="button" data-bs-toggle="modal" data-bs-target="#addCrewModal">
                    <i class="me-2" data-feather="user-plus"></i>
                    Tambah Karyawan
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTableShowCrew" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Crew</th>
                                <th>Status</th>
                                <th>Keterangan</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__currentLoopData = $eventCrews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($crew->karyawan->nama); ?></td>
                                    <td><?php echo e($crew->status->status_crew); ?></td>
                                    <td><?php echo e($crew->keterangan->keterangan_crew); ?></td>
                                    <td>
                                        
                                        <a href="<?php echo e(route('event.updateCrew', ['crewId' => $crew->id])); ?>"
                                            class="btn btn-warning btn-sm" type="button" data-bs-toggle="modal"
                                            data-bs-target="#editModal<?php echo e($crew->id); ?>">
                                            <i class="fas
                                        fa-edit me-2"></i>Edit
                                        </a>

                                        
                                        <a href="<?php echo e(url('event/' . $crew->id . '/delete-crew')); ?>" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal<?php echo e($crew->id); ?>" class="btn btn-danger btn-sm"
                                            type="button">
                                            <i class="fas fa-trash me-2"></i>Hapus
                                        </a>

                                        
                                        <?php echo $__env->make('components.modal-event.modal-update-crew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        
                                        <?php echo $__env->make('components.modal-event.modal-delete-crew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Add Crew Modal -->
            <?php echo $__env->make('components.modal-event.modal-add-crew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <pre hidden id="myText">
Venue : <?php echo e($events->venue); ?>

Loading : <?php echo e($events->tanggal_loading_formatted); ?>

Acara : <?php echo e($tanggal_acara); ?>

Client : <?php echo e($events->client); ?>

Spek : <?php echo e($events->ukuran_led); ?>

Crew :<?php $__currentLoopData = $eventCrews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($crew->karyawan->nama); ?>,
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </pre>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        const copyContent = () => {
            const textElement = document.getElementById('myText');
            let text = textElement.innerText;

            navigator.clipboard.writeText(text)
                .then(() => console.log('Content copied to clipboard'))
                .catch(err => console.error('Failed to copy: ', err));
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/event/show.blade.php ENDPATH**/ ?>