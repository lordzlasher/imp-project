<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Report Event - IMP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: small;
        }

        h1,
        h3 {
            margin-bottom: 20px;
            text-align: center;
            /* Memberikan ruang di bawah judul */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        td {
            background-color: #fff;
        }


        tfoot {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div id="header">
        <h1>REKAPAN EVENT</h1>
        <h3>INDONESIA MULTIMEDIA PROJECT</h3>
    </div>

    <table border='1'>
        <thead>
            <tr>
                <th>NO</th>
                <th>TANGGAL LOADING</th>
                <th>TANGGAL ACARA</th>
                <th>UKURAN</th>
                <th>VENUE</th>
                <th>CREW</th>
                <th>STATUS</th>
                <th>KETERANGAN</th>
                <th>NOTE</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $count = 1;
            ?>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $eventCrews = $event->eventCrew;
                    $rowCount = count($eventCrews);
                ?>

                
                <?php if($rowCount > 0): ?>
                    <?php $__currentLoopData = $eventCrews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $eventCrew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if($index === 0): ?>
                                <td rowspan="<?php echo e($rowCount); ?>"><?php echo e($count++); ?></td>
                                <td rowspan="<?php echo e($rowCount); ?>">
                                    <?php echo e($event->getTanggalLoadingFormattedAttribute()); ?>

                                </td>
                                <td rowspan="<?php echo e($rowCount); ?>"><?php echo e($event->getFormattedDateRangeAttribute()); ?>

                                </td>
                                <td rowspan="<?php echo e($rowCount); ?>"><?php echo e($event->ukuran_led); ?></td>
                                <td rowspan="<?php echo e($rowCount); ?>"><?php echo e($event->venue); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($eventCrew->karyawan->nama); ?></td>
                            <td><?php echo e($eventCrew->status->status_crew); ?></td>
                            <td><?php echo e($eventCrew->keterangan->keterangan_crew); ?></td>
                            <?php if($index === 0): ?>
                                <td rowspan="<?php echo e($rowCount); ?>"><?php echo e($event->note); ?></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    
                    <tr>
                        <td><?php echo e($count++); ?></td>
                        <td><?php echo e($event->getTanggalLoadingFormattedAttribute()); ?></td>
                        <td><?php echo e($event->getFormattedDateRangeAttribute()); ?></td>
                        <td><?php echo e($event->ukuran_led); ?></td>
                        <td><?php echo e($event->venue); ?></td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td><?php echo e($event->note); ?></td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="8">TOTAL EVENT</td>
                <td><?php echo e($count - 1); ?></td>
            </tr>
        </tfoot>
    </table>
</body>

</html>
<?php /**PATH D:\Unud\KP\KP IMP\DONE\sb-admin-laravel-done\resources\views/report-pdf/event-report.blade.php ENDPATH**/ ?>