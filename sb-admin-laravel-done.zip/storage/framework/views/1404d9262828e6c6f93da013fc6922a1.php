 
 <div class="modal fade" id="deleteModal<?php echo e($user->id); ?>" tabindex="-1" role="dialog"
     aria-labelledby="exampleModalLabel" aria-hidden="true">
     
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabel">Sure want to Delete?
                 </h5>
                 <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
             </div>
             <div class="modal-body">Select "Delete" below if you are sure to delete the
                 data.</div>
             <div class="modal-footer">
                 <button class="btn btn-primary" type="button" data-bs-dismiss="modal">Cancel</button>
                 <form method="GET" action="<?php echo e(url('user-management/' . $user->id . '/delete')); ?>">
                     <?php echo csrf_field(); ?>
                     <button class="btn btn-danger"
                         href="<?php echo e(url('user-management/' . $user->id . '/delete')); ?>">Delete</button>
                 </form>
             </div>
         </div>
     </div>
 </div>
<?php /**PATH D:\Unud\KP\KP IMP\DONE\sb-admin-laravel-done\resources\views/components/modal-user/modal-delete.blade.php ENDPATH**/ ?>