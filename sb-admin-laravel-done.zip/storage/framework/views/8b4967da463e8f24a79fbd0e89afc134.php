


<?php
    $useHeader = true;
    $useCompactHeader = true;
?>


<?php $__env->startSection('header-icon', 'user'); ?>
<?php $__env->startSection('header-title', 'Detail Karyawan'); ?>
<?php $__env->startSection('back-link', route('karyawan.index')); ?>
<?php $__env->startSection('back-desc', 'Back to Karyawan List'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(!empty($crewEvents) && isset($crewEvents[0])): ?>
        <div class="container-fluid px-4">

            <!-- Account page navigation-->
            <nav class="nav nav-borders">
                <a class="nav-link" href="<?php echo e(url('karyawan/' . $crewEvents[0]->id_karyawan)); ?>">Profile</a>
                <a class="nav-link active" href="<?php echo e(url('karyawan/list-job/' . $crewEvents[0]->id_karyawan)); ?>">List Job</a>
            </nav>

            <hr class="mt-0 mb-4" />

            <div class="col">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>List Job</span>
                        <a class="btn btn-sm btn-primary" href="<?php echo e(url('karyawan')); ?>" type="button">
                            <i class="me-2" data-feather="file"></i>
                            Download Report
                        </a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal Acara</th>
                                        <th>Venue</th>
                                        <th>Status</th>
                                        <th>Note</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $crewEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crewEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($loop->iteration); ?></th>
                                            <td><?php echo e($crewEvent->event->getFormattedDateRangeAttribute()); ?></td>
                                            <td><?php echo e($crewEvent->event->venue); ?></td>
                                            <td><?php echo e($crewEvent->status_crew); ?></td>
                                            <td><?php echo e($crewEvent->keterangan); ?></td>
                                            <td>
                                                <a class="btn btn-sm btn-info me-2"
                                                    href="<?php echo e(url('event/' . $crewEvent->event->id)); ?>"><i
                                                        class="fas fa-eye me-2"></i>Detail</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <hr class="mt-0 mb-4" />

            <div class="row justify-content-end">
                <div class="col-lg-3 mb-4">
                    <!-- Billing card 1-->
                    <div class="card h-80 border-start-lg border-start-primary">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <div class="text mb-2">Total Event</div>
                                    <div class="h1"><?php echo e(count($crewEvents)); ?> <span
                                            class="fw-500 text-primary">events</span>
                                    </div>
                                </div>
                                <div class="ms-2"><i class="fas fa-briefcase fa-2x text-gray-200"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="text-center mt-4">
            <h1>Tidak terdapat data.</h1>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/karyawan/list-job.blade.php ENDPATH**/ ?>