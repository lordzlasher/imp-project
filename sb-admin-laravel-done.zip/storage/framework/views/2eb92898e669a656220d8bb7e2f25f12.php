<!-- Update Keterangan Modal -->
<div class="modal fade" id="updateKategoriEvent<?php echo e($kategori->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="updateKeteranganModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form enctype="multipart/form-data" action="<?php echo e(route('kategori-event.update', $kategori->id)); ?>"
                method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="updateKeteranganModalLabel">Edit Keterangan Crew</h5>
                    <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="card-body">
                        <div id="crew-form-container">
                            <!-- Form kategori-->
                            <div class="kategori gx-3 mb-3">
                                <!-- Form Keterangan Crew -->
                                <div class="mb-3">
                                    <label class="small mb-1" for="inputNote">Kategori Event</label>
                                    <textarea class="form-control <?php $__errorArgs = ['kategori_event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kategori_event" id="kategori_event"><?php echo e($kategori->kategori_event); ?></textarea>
                                    <?php $__errorArgs = ['kategori_event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <label class="small mb-1 text-danger" for="inputNote"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-danger" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-primary" type="submit">Update
                        Kategori</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\Unud\KP\KP IMP\DONE\sb-admin-laravel-done\resources\views/components/modal-kategori-event/modal-update.blade.php ENDPATH**/ ?>