<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Report Karyawan - IMP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: small;
        }

        h1,
        h3,
        h4 {
            margin-bottom: 10px;
            text-align: center;
            /* Memberikan ruang di bawah judul */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        td {
            background-color: #fff;
        }


        tfoot {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <h1>REKAPAN EVENT KARYAWAN</h1>
    <h3>INDONESIA MULTIMEDIA PROJECT</h3>
    <h4><?php echo e($crewEvents[0]->karyawan->nama); ?></h4>
    <h4><?php echo e($crewEvents[0]->karyawan->jenis_bank); ?> | <?php echo e($crewEvents[0]->karyawan->nomer_rekening); ?></h4>

    <table border='1'>
        <thead>
            <tr>
                <th>NO</th>
                <th>TANGGAL ACARA</th>
                <th>UKURAN</th>
                <th>VENUE</th>
                <th>STATUS</th>
                <th>KETERANGAN</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $crewEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crewEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($crewEvent->event->getFormattedDateRangeAttribute()); ?></td>
                    <td><?php echo e($crewEvent->event->ukuran_led); ?></td>
                    <td><?php echo e($crewEvent->event->venue); ?></td>
                    <td><?php echo e($crewEvent->status->status_crew); ?></td>
                    <td><?php echo e($crewEvent->keterangan->keterangan_crew); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="5">TOTAL EVENT</td>
                <td><?php echo e(count($crewEvents)); ?></td>
            </tr>
        </tfoot>
    </table>
</body>

</html>
<?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/report-pdf/karyawan-report.blade.php ENDPATH**/ ?>