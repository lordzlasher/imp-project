<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <!--  Title -->
    <title>Indonesia Multimedia Project - IMP</title> <!--  Favicon -->
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('/landingpage/dist/images/logos/favicon.ico')); ?>">
    <!--  Aos -->
    <link rel="stylesheet" href="<?php echo e(asset('/landingpage/dist/libs/aos/dist/aos.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/landingpage/dist/libs/owl.carousel/dist/assets/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/landingpage/dist/css/style.min.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <div class="page-wrapper p-0 overflow-hidden">
        <div class="body-wrapper overflow-hidden">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('/landingpage/dist/libs/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/landingpage/dist/libs/aos/dist/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('/landingpage/dist/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/landingpage/dist/libs/owl.carousel/dist/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/landingpage/dist/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('/package/dist/libs/moment-js/moment.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/layouts/guest.blade.php ENDPATH**/ ?>