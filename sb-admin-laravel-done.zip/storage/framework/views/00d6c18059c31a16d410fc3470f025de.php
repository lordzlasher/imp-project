

<?php
    $useHeader = true;
    $useCompactHeader = false;
?>

<?php $__env->startSection('header-icon', 'plus-square'); ?>
<?php $__env->startSection('header-title', 'CRUD Status Crew'); ?>
<?php $__env->startSection('header-subtitle', 'Data Status Crew pada Event Indonesia Multimedia Project'); ?>


<?php $__env->startSection('content'); ?>
    <!-- Main page content-->
    <div class="container-fluid px-4 mt-n10">

        <!-- Include Alert Component -->
        <?php if(session('success')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'success'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('success')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php elseif(session('warning')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'warning'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('warning')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php elseif(session('danger')): ?>
            <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('alertType', 'danger'); ?>
                <?php $__env->slot('alertMessage'); ?>
                    <?php echo e(session('danger')); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php else: ?>
        <?php endif; ?>

        
        <?php echo $__env->make('components.modal-status-crew.modal-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Table Status Crew</span>
                <a class="btn btn-sm btn-success" type="button" href="<?php echo e(route('status-crew.store')); ?>" data-bs-toggle="modal"
                    data-bs-target="#addStatusModal">
                    <i class="me-2" data-feather="plus"></i>
                    Add New Status
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($row->status_crew); ?></td>
                                    <td>
                                        
                                        <a href="<?php echo e(route('status-crew.update', $row->id)); ?>" class="btn btn-warning btn-sm"
                                            type="button" data-bs-toggle="modal"
                                            data-bs-target="#updateStatusModal<?php echo e($row->id); ?>">
                                            <i class="fas
                                        fa-edit me-2"></i>Edit
                                        </a>

                                        
                                        <a href="<?php echo e(url('status-crew/' . $row->id . '/delete')); ?>" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal<?php echo e($row->id); ?>" class="btn btn-danger btn-sm"
                                            type="button">
                                            <i class="fas fa-trash me-2"></i>Hapus
                                        </a>

                                        <!-- Update Modal -->
                                        <?php echo $__env->make('components.modal-status-crew.modal-update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        
                                        <?php echo $__env->make('components.modal-status-crew.modal-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/status-crew/index.blade.php ENDPATH**/ ?>