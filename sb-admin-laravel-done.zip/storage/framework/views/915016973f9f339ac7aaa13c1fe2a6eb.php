<header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
    <div class="container-xl px-4">
        <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
                <div class="col-auto mt-4">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i data-feather="<?php echo $__env->yieldContent('header-icon'); ?>"></i></div>
                        <?php echo $__env->yieldContent('header-title'); ?>
                    </h1>
                    <div class="page-header-subtitle"><?php echo $__env->yieldContent('header-subtitle'); ?></div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\Unud\KP\KP IMP\DONE\sb-admin-laravel-done\resources\views/components/header.blade.php ENDPATH**/ ?>