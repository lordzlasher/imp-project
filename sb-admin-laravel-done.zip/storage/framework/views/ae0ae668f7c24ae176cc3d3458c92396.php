<footer class="footer-admin mt-auto footer-light">
    <div class="container-xl px-4">
        <div class="row">
            <div class="col-md-6 small">Copyright &copy; Indonesia Multimedia Project 2023</div>
            <div class="col-md-6 text-md-end small">
                <a href="#!">Privacy Policy</a>
                &middot;
                <a href="#!">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\Unud\KP\KP IMP\DONE\sb-admin-laravel-done\resources\views/components/footer.blade.php ENDPATH**/ ?>