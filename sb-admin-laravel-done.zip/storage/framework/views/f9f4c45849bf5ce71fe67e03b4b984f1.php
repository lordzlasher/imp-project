 
 <div class="modal fade" id="editModal<?php echo e($crew->id); ?>" tabindex="-1" role="dialog"
     aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
     
     <div class="modal-dialog modal-xl" role="document">
         <div class="modal-content">
             <form enctype="multipart/form-data" action="<?php echo e(route('event.updateCrew', ['crewId' => $crew->id])); ?>"
                 method="POST">
                 <?php echo csrf_field(); ?>
                 <?php echo method_field('PUT'); ?>
                 <div class="modal-header">
                     <h5 class="modal-title" id="exampleModalCenterTitle">Edit Karyawan
                     </h5>
                     <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                 </div>
                 <div class="modal-body">
                     <div class="card-body">
                         <div id="crew-form-container">
                             <!-- Form Row-->
                             <div class="row gx-3 mb-3">
                                 <!-- Form Crew -->
                                 <div class="mb-3">
                                     <label class="small mb-1" for="inputCrew">Crew</label>
                                     <input class="form-control" type="text" value="<?php echo e($crew->karyawan->nama); ?>"
                                         readonly />
                                 </div>
                                 <!-- Form Status Crew -->
                                 <div class="mb-3">
                                     <label class="small mb-1" for="inputStatus">Status</label>
                                     <select class="form-select" name="status_crew" id="status_crew">
                                         <option value="<?php echo e($crew->status->id); ?>" selected hidden>
                                             <?php echo e($crew->status->status_crew); ?>

                                         </option>
                                         <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($status->id); ?>">
                                                 <?php echo e($status->status_crew); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                     <?php $__errorArgs = ['status_crew'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         <label class="small mb-1 text-danger" for="inputStatus"><?php echo e($message); ?></label>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <!-- Form Keterangan Crew -->
                                 <div class="mb-3">
                                     <label class="small mb-1" for="inputStatus">Keterangan</label>
                                     <select class="form-select" name="keterangan_crew" id="keterangan_crew">
                                         <option value="<?php echo e($crew->keterangan->id); ?>" selected hidden>
                                             <?php echo e($crew->keterangan->keterangan_crew); ?>

                                         </option>
                                         <?php $__currentLoopData = $keterangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keterangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($keterangan->id); ?>">
                                                 <?php echo e($keterangan->keterangan_crew); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                     <?php $__errorArgs = ['keterangan_crew'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         <label class="small mb-1 text-danger"
                                             for="inputStatus"><?php echo e($message); ?></label>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="modal-footer">
                     <button class="btn btn-danger" type="button" data-bs-dismiss="modal">Close</button>
                     <button class="btn btn-primary" type="submit">Save
                         changes</button>
                 </div>
             </form>
         </div>
     </div>
 </div>
<?php /**PATH D:\Unud\KP\KP IMP\sb-admin-laravel\resources\views/components/modal-event/modal-update-crew.blade.php ENDPATH**/ ?>