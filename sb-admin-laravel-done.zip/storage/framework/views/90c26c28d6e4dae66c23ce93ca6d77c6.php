<div class="alert alert-<?php echo e($alertType); ?> alert-dismissible fade show" role="alert">
    <?php echo e($alertMessage); ?>

    <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php /**PATH D:\Unud\KP\KP IMP\DONE\sb-admin-laravel-done\resources\views/components/alert.blade.php ENDPATH**/ ?>