<div class="alert alert-{{ $alertType }} alert-dismissible fade show" role="alert">
    {{ $alertMessage }}
    <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
