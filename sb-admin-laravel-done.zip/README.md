<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>

# SISTEM INFORMASI IMP

Sistem informasi manajemen rental LED Indonesia Multimedia Project

## INSTALASI

- [Laravel 10](https://laravel.com)
- [Composer](https://getcomposer.org/)
- [Laravel Breeze](https://laravel.com/docs/10.x/starter-kits#laravel-breeze)
- [DomPDF](https://github.com/dompdf/dompdf)
- [Laravel Excel](https://laravel-excel.com/)

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

